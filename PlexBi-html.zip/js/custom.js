
$("close").click(function(){

$("button.rd-navbar-toggle").removeClass("active");
});
$(".close").click(function (){
// $('#slidePanel').toggle( "slide",{direction: 'right'});
if($('.rd-navbar-nav-wrap').hasClass('active')){
$('.rd-navbar-nav-wrap').removeClass('active');
}
else{
$('#btnDiv').addClass('rotated');
}
});


$(".close").click(function (){
// $('#slidePanel').toggle( "slide",{direction: 'right'});
if($('.rd-navbar-toggle').hasClass('active')){
$('.rd-navbar-toggle').removeClass('active');
}
else{
$('#btnDiv').addClass('rotated');
}
});

(function ($) {
    var o = $('.rd-navbar');
    if (o.length > 0) {
       // include('../dist/js/jquery.rd-navbar.js');

        $(document).ready(function () {
            o.RDNavbar({
                stickUpClone: false,
                stickUpOffset: 170
            });
        });
    }
})(jQuery);



    jQuery(function ($) {
     
      // start all the timers
      $('.timer').each(count);
      
      // restart a timer when a button is clicked
      $( window ).scroll(function () {console.log($(window).scrollTop());
    if($(window).scrollTop() > 300 && $(window).scrollTop() < 850)
    {
       $('.timer').each(count);
     }
      });
      
      function count(options) {
        var $this = $(this);
        options = $.extend({}, options || {}, $this.data('countToOptions') || {});
        $this.countTo(options);
      }
    });



jQuery(document).ready(function($){
    var offset = $( "header" ).offset();
    checkOffset();

    $(window).scroll(function() {
        checkOffset();
    });

    function checkOffset() {
        if ( $(document).scrollTop() > offset.top){
            $('header').addClass('fixed');
        } else {
            $('header').removeClass('fixed');
        } 
    }

});



$(document).ready(function(){
  var owl = $('.banner-slide');
  owl.owlCarousel({
    loop:true,
    animateOut: 'fadeOut',
    margin:10,
    nav:false,
    items: 1,
    smartSpeed:450
  });
  
  // Custom Button
  $('.customNextBtn').click(function() {
    owl.trigger('next.owl.carousel');
  });
  $('.customPreviousBtn').click(function() {
    owl.trigger('prev.owl.carousel');
  });
  
});





$(".toggle-password").click(function() {

  $(this).toggleClass("fa-eye-slash fa-eye");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }
});


$('.testmons').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    dots:false,
         navText: ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],

    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})


$('.nw-media').owlCarousel({
    loop:true,
    margin:5,
    nav:true,
    dots:false,
         navText: ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],

    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3
        }
    }
})

var rellax = new Rellax('.rellax');